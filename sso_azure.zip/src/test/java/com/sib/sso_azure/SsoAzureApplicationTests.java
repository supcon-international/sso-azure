package com.sib.sso_azure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsoAzureApplicationTests {

	@Test
	void contextLoads() {
	}

}
