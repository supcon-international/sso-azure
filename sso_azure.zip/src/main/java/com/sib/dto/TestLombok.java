package com.sib.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TestLombok {
    private String field;
}
