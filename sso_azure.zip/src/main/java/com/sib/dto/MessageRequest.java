package com.sib.dto;

import lombok.Data;

@Data
public class MessageRequest {
    private String message;
}
