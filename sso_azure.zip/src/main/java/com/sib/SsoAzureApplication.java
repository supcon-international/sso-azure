package com.sib;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsoAzureApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsoAzureApplication.class, args);
	}

}
